﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;

namespace CSharpAsp.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            int nextYear = DateTime.Now.Year + 1;
            ViewData["nextyear"] = nextYear;
            ViewData["countdown"] = this.GetLabel(nextYear);

            return View();
        }
        private string GetLabel(int nextYear)
        {
            DateTime endTime = new DateTime(nextYear, 07, 04, 0, 0, 0);
            TimeSpan ts = endTime.Subtract(DateTime.Now);
            return string.Format("{0} Days, {1} Hours, {2} Minutes, {3} Seconds til Independence Day.", ts.Days, ts.Hours, ts.Minutes, ts.Seconds);
        }
    }
}
